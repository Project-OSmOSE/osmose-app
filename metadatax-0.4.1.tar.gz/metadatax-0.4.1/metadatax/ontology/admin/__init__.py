"""Ontology admin"""

from .label import LabelAdmin
from .physical_descriptor import PhysicalDescriptorAdmin
from .sound import SoundAdmin
from .source import SourceAdmin
