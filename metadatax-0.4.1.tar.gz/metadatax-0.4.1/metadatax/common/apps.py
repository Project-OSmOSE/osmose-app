from django.apps import AppConfig


class MetadataxCommonConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "metadatax.common"
    verbose_name = "Metadatax Common"
