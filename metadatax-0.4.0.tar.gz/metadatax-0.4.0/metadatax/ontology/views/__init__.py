"""Ontology views"""

from .label import LabelViewSet
from .physical_descriptor import PhysicalDescriptorViewSet
from .sound import SoundViewSet
from .source import SourceViewSet
